import { findActiveCustomersOptions, findAllCustomers, findCustomerById, getCustomerTotalRows } from "./customers.repository.js"

export async function getAllCustomers() {
    return findAllCustomers()
}

export async function getCustomerDetail(id, orderDirection) {
    const customer = await findCustomerById(id, orderDirection)

    if (!customer) {
        return null
    }

    const totalRows = await getCustomerTotalRows(id)

    return {
        ...customer,
        total_rows: Number(totalRows.total_rows)
    }
}

export async function getActiveCustomersOptions() {
    return findActiveCustomersOptions()
}