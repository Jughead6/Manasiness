import pool from "../../config/db.js"

export async function findAllCustomers() {
    const result = await pool.query(`
        SELECT id, name, image
        FROM users
        WHERE role = 'customer'
        ORDER BY id ASC
    `)

    return result.rows
}

export async function findCustomerById(id, orderDirection) {
    const result = await pool.query(`
        SELECT
            sales.sold_at AS date,
            products.name AS product,
            sales.sale_price AS price,
            sales.quantity,
            sales.state,
            users.name
        FROM sales
        JOIN users ON sales.user_id = users.id
        JOIN products ON sales.product_id = products.id
        WHERE sales.user_id = $1
        ORDER BY sales.sold_at ${orderDirection}
    `, [id])

    return result.rows[0] || null
}

export async function findActiveCustomersOptions() {
    const result = await pool.query(`
        SELECT id, name
        FROM users
        WHERE role = 'customer' AND is_active = true
        ORDER BY name
    `)

    return result.rows
}

export async function getCustomerTotalRows(id) {
    const result = await pool.query(`
        SELECT COUNT(*) AS total_rows
        FROM sales
        WHERE user_id = $1
    `, [id])

    return result.rows[0]
}