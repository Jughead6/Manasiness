import { getActiveCustomersOptions, getAllCustomers, getCustomerDetail } from "./customers.service.js"

export async function getCustomers(req, res, next) {
    try {
        const customers = await getAllCustomers()
        
        res.json(customers)
    } catch (error) {
        next(error)
    }
}

export async function getCustomerById(req, res, next) {
    const { sort = 'recent' } = req.query
    const orderDirection = sort === 'oldest' ? 'ASC' : 'DESC'
    const { id } = req.params

    try {
        const customer = await getCustomerDetail(id, orderDirection)

        if (!customer) {
            return res.status(404).json({error: 'Customer not found'})
        }

        res.json(customer)
    } catch (error) {
        next(error)
    }
}


export async function getCustomerOptions(req, res, next) {
    try {
        const customers = await getActiveCustomersOptions()

        res.json(customers)
    } catch (error) {
        next(error)
    }
}
