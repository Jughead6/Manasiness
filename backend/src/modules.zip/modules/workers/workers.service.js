import { findActiveWorkersOptions, findAllWorkers, findWorkerById, getWorkerTotalRows } from "./workers.repository.js"

export async function getAllWorkers() {
    return findAllWorkers()
}

export async function getWorkerDetail(id, orderDirection) {
    const worker = await findWorkerById(id, orderDirection)

    if (!worker) {
        return null
    }

    const totalRows = await getWorkerTotalRows(id)

    return {
        ...worker,
        total_rows: Number(totalRows.total_rows)
    }
}

export async function getActiveWorkersOptions() {
    return findActiveWorkersOptions()
}