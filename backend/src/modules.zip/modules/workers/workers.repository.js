import pool from "../../config/db.js"

export async function findAllWorkers() {
    const result = await pool.query(`
        SELECT id, name, image
        FROM users
        WHERE role = 'worker'
        ORDER BY id ASC
    `)

    return result.rows
}

export async function findWorkerById(id, orderDirection) {
    const result = await pool.query(`
        SELECT
            staff.created_at AS date,
            staff.salary,
            staff.state,
            users.name
        FROM staff
        JOIN users ON staff.user_id = users.id
        WHERE staff.user_id = $1
        ORDER BY staff.created_at ${orderDirection}
    `, [id])

    return result.rows[0] || null
}

export async function findActiveWorkersOptions() {
    const result = await pool.query(`
        SELECT id, name
        FROM users
        WHERE role = 'worker' AND is_active = true
        ORDER BY name
    `)

    return result.rows
}

export async function getWorkerTotalRows(id) {
    const result = await pool.query(`
        SELECT COUNT(*) AS total_rows
        FROM staff
        WHERE user_id = $1
    `, [id])

    return result.rows[0]
}