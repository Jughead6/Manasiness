import { getActiveWorkersOptions, getAllWorkers, getWorkerDetail } from "./workers.service.js"

export async function getWorkers(req, res) {
    try {
        const workers = await getAllWorkers()

        res.json(workers)
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
}

export async function getWorkerById(req, res) {
    const { sort = 'recent'} = req.query
    const orderDirection = sort === 'oldest' ? 'ASC' : 'DESC'
    const { id } = req.params

    try {
        const worker = await getWorkerDetail(id, orderDirection)

        if(!worker) {
            return res.status(404).json({error: 'Worker not found!'})
        }

        res.json(worker)
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
}

export async function getWorkerOptions(req, res) {
    try {
        const workers = await getActiveWorkersOptions()

        res.json(workers)
    } catch (error) {
        res.status(500).json({ error: error.message})
    }
}