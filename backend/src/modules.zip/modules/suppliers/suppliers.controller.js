import { getActiveSuppliersOptions, getAllSuppliers, getSupplierDetail } from "./suppliers.service.js"

export async function getSuppliers(req, res, next) {
    try {
        const suppliers = await getAllSuppliers()

        res.json(suppliers)
    } catch (error) {
        next(error)
    }
}

export async function getSupplierById(req, res, next) {
    const { sort = 'recent' } = req.query
    const orderDirection = sort === 'oldest' ? 'ASC' : 'DESC'
    const { id } = req.params

    try {
        const supplier = await getSupplierDetail(id , orderDirection)

        if(!supplier) {
            return res.status(404).json({ error: 'Supplier not found'})
        }

        res.json(supplier)
    } catch (error) {
        next(error)
    }
}

export async function getSupplierOptions(req, res, next) {
    try {
        const suppliers = await getActiveSuppliersOptions()

        res.json(suppliers)
    } catch (error) {
        next(error)
    }
}