import pool from "../../config/db.js"

export async function findAllSuppliers() {
    const result = await pool.query(`
        SELECT id, name, image
        FROM users
        WHERE role = 'supplier'
        ORDER BY id ASC
    `)

    return result.rows
}

export async function findSupplierById(id, orderDirection) {
    const result = await pool.query(`
        SELECT
            orders.ordered_at AS date,
            products.name AS product,
            orders.cost_price AS price,
            orders.quantity,
            orders.state,
            users.name
        FROM orders
        JOIN users ON orders.user_id = users.id
        JOIN products ON orders.product_id = products.id
        WHERE orders.user_id = $1
        ORDER BY orders.ordered_at ${orderDirection}
    `, [id])

    return result.rows[0] || null
}

export async function findActiveSuppliersOptions() {
    const result = await pool.query(`
        SELECT id, name
        FROM users
        WHERE role = 'supplier' AND is_active = true
        ORDER BY name
    `)

    return result.rows
}

export async function getSupplierTotalRows(id) {
    const result = await pool.query(`
        SELECT COUNT(*) AS total_rows
        FROM orders
        WHERE user_id = $1
    `, [id])

    return result.rows[0]
}