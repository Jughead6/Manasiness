import { findActiveSuppliersOptions, findAllSuppliers, findSupplierById, getSupplierTotalRows } from "./suppliers.repository.js"

export async function getAllSuppliers() {
    return findAllSuppliers()
}

export async function getSupplierDetail(id, orderDirection) {
    const supplier = await findSupplierById(id, orderDirection)

    if (!supplier) {
        return null
    }

    const totalRows = await getSupplierTotalRows(id)

    return {
        ...supplier,
        total_rows: Number(totalRows.total_rows)
    }
}

export async function getActiveSuppliersOptions() {
    return findActiveSuppliersOptions()
}