import './PersonActions.css'

import { StepForward, StepBack, } from 'lucide-react'

function PersonActions() {
    return (
        <div className="person-buttons">
            <button><StepBack/></button>
            <button><StepForward/></button>
        </div>
    )
}

export default PersonActions