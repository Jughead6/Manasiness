import './EntityActions.css'

function EntityActions() {
    return (
        <div className="entity-toolbar">
            <button>Editar</button>
            <button>Eliminar</button>
        </div>
    )
}

export default EntityActions