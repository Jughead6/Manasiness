import './TableActions.css'

function TableActions() {
    return (
        <div className="table-buttons">
            <button>Register</button>
            <button>Cancel</button>
        </div>
    )
}

export default TableActions