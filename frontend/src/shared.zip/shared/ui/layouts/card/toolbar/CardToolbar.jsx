import './CardToolbar.css'

import SearchBarCard from './searchbar/CardSearchInput.jsx'

function CardToolbar({ action }) {
    return (
        <div className="toolbar">
            <SearchBarCard action={action}/>
        </div>
    )
}

export default CardToolbar