import './CardGrid.css'

import { useNavigate } from 'react-router-dom'

function CardGrid({ action, route }) {
    const navigate = useNavigate()
    
    return (
        <div className="card-grid">
            {action.map((item) => (
                <div className="cards" key={item.id}>
                    <h3>{item.name}</h3>
                    <img src={item.image} alt={item.name} />
                    <button onClick={() => navigate(`/dashboard/${route}/${item.id}`)}>View</button>
                </div>
            ))}
        </div>
    )
}

export default CardGrid

